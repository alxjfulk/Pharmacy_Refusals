# -*- coding: utf-8 -*-
"""
Created on Sat Jun  7 11:05:17 2025

@author: bigfo
"""
import sys

# Guard against running with `python app.py` instead of the Streamlit CLI
if __name__ == "__main__" and not sys.argv[0].endswith("streamlit"):
    print("\nThis application is designed to run with Streamlit.")
    print("To start the app correctly, follow these steps:")
    print("  1. Open your terminal or command prompt.")
    print("  2. Navigate to the directory containing this app.py file:")
    print("       cd /path/to/your/project")
    print("  3. Launch the app using Streamlit:")
    print("       streamlit run app.py")
    print("\nExiting now.")
    sys.exit(0)
    
# app.py
import os
import multiprocessing as mp
import streamlit as st
# Optionally print and change working directory if needed
# print(os.getcwd())
os.chdir(r'C:\Users\bigfo\OneDrive\Desktop\Pharmacy Refusals Stuff\modular_code')

from PharmacyCityState_modular3 import extract_pharmacy_data
from Zip_to_censustract_modular2 import tie_census_info
from travel_time_helpers import compute_raw_travel_times
from compute_t_matrices_1 import batch_process_all
#from ph_computations import compute_accessibility_metrics

st.set_page_config(page_title="Pharmacy TDA Dashboard", layout="wide")

st.title("Pharmacy Accessibility & TDA Explorer")

# — Sidebar inputs —
city  = st.sidebar.text_input("City", value="Milwaukee")
state = st.sidebar.text_input("State (abbrev.)", value="WI")
api   = st.sidebar.text_input("Google API Key", type="password")
thresh = st.sidebar.slider("Coverage threshold (minutes)", 5, 60, 30)

ph_folder   = st.sidebar.text_input("Pharmacy temp folder", value="pharmacies")
tract_folder= st.sidebar.text_input("Tract temp folder",    value="tracts")
raw_folder  = st.sidebar.text_input("Raw travel folder",    value="raw_times")
wdm_folder  = st.sidebar.text_input("Weighted matrix folder", value="wdm")
tda_folder  = st.sidebar.text_input("TDA output folder",    value="tda_results")

run_btn = st.sidebar.button("▶️ Run Pipeline")

if run_btn:
    st.write("## Running full pipeline…")
    progress = st.progress(0)

    # Step 1
    st.write("1/5: Extract pharmacy data")
    extract_pharmacy_data(city, state, ph_folder, api)
    progress.progress(20)

    # Step 2
    st.write("2/5: Attach census tracts")
    tie_census_info(ph_folder, tract_folder)
    progress.progress(40)

    # Step 3
    st.write("3/5: Compute raw walk & drive times")
    tract_csv = os.path.join(tract_folder, f"{city}{state}_tract_data.csv")
    compute_raw_travel_times(
        tract_csv_path=tract_csv,
        travel_folder=raw_folder,
        city=city,
        state=state,
        max_workers=mp.cpu_count(),
        buffer_deg=0.02
    )
    progress.progress(60)

    # Step 4
    st.write("4/5: Compute weighted distance matrices (d̃ and d)")
    batch_process_all(
        input_folder=tract_folder,
        travel_folder=raw_folder,
        output_folder=wdm_folder,
        travel_types=['drive','walk']
    )
    progress.progress(80)

    # Step 5
    st.write("5/5: Compute accessibility & persistence metrics")
    # compute_accessibility_metrics(
    #     matrix_folder=wdm_folder,
    #     tract_folder=tract_folder,
    #     output_folder=tda_folder,
    #     matrix_type='d',
    #     threshold=thresh
    # )
    progress.progress(100)
    st.success("✅ Pipeline complete!")

    # Show summary table
    st.write("### Coverage summary")
    summary_csv = os.path.join(tda_folder, f"{city}{state}_d_drive_summary.csv")
    if os.path.exists(summary_csv):
        import pandas as pd
        df = pd.read_csv(summary_csv)
        st.dataframe(df)
    else:
        st.warning("Summary CSV not found.")
