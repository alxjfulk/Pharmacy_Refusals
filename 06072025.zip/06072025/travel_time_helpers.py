# travel_time_helpers.py
"""
Helper functions to compute raw walk and drive travel-time matrices between
points (e.g., pharmacies) using OSMnx + NetworkX. Results are cached to .npy.
"""

import os                          # file path operations
import numpy as np                 # numerical arrays
import pandas as pd                # for reading the CSV of locations
import multiprocessing as mp       # to parallelize shortest‐path calculations
import osmnx as ox                 # to download and work with OSM street networks
import networkx as nx              # for graph algorithms

def compute_raw_travel_times(
    tract_csv_path: str,
    travel_folder: str,
    city: str,
    state: str,
    max_workers: int = None,
    buffer_deg: float = 0.02
):
    """
    Read <city><state>_tract_data.csv, build a small OSMnx graph around the
    points, compute pairwise walk & drive times in parallel, and save two
    numpy matrices:
      - {travel_folder}/{city}{state}_walk.npy
      - {travel_folder}/{city}{state}_drive.npy

    Parameters:
      tract_csv_path : path to the CSV with 'latitude' and 'longitude' columns
      travel_folder  : directory to save the .npy files (will be created)
      city, state    : strings used to build the basename (e.g. 'Milwaukee', 'WI')
      max_workers    : number of processes to spawn (defaults to cpu_count())
      buffer_deg     : padding (in degrees) around min/max lat/lon for bbox
    """
    # ensure travel_folder exists
    os.makedirs(travel_folder, exist_ok=True)

    # load all lat/lon into numpy arrays
    df = pd.read_csv(tract_csv_path)
    lats = df['latitude'].values
    lons = df['longitude'].values
    n = len(df)  # number of points

    # define the base filename for outputs
    basename = f"{city}{state}"
    walk_npy = os.path.join(travel_folder, f"{basename}_walk.npy")
    drive_npy = os.path.join(travel_folder, f"{basename}_drive.npy")

    # default number of parallel workers
    if max_workers is None:
        max_workers = mp.cpu_count()

    def build_and_compute(mode: str, npy_path: str):
        """
        Build OSMnx graph for `mode` ('walk' or 'drive'), then compute
        the shortest‐path times in parallel with a progress bar, saving to npy_path.
        """
        # skip if file already exists
        if os.path.exists(npy_path):
            print(f"  • {mode}.npy already exists, skipping compute.")
            return

        # bounding box
        north, south = lats.max() + buffer_deg, lats.min() - buffer_deg
        east,  west  = lons.max() + buffer_deg, lons.min() - buffer_deg
        bbox = (north, south, east, west)
        print(f"  • Loading '{mode}' graph in bbox: {bbox}")

        # load & simplify
        G = ox.graph_from_bbox(bbox, network_type=mode, simplify=True)
        if mode == "drive":
            ox.speed.add_edge_speeds(G, fallback=40.2336)
            ox.speed.add_edge_travel_times(G)

        # snap sites → nodes once
        nodes = ox.distance.nearest_nodes(G, lons, lats)

        # prepare all unique pairs i<j
        pairs = [(i, j) for i in range(n) for j in range(i+1, n)]

        # choose route‐cost function
        if mode == "walk":
            def sp(pair):
                length = nx.shortest_path_length(
                    G, nodes[pair[0]], nodes[pair[1]], weight='length'
                )
                return length / 1.42
        else:
            def sp(pair):
                return nx.shortest_path_length(
                    G, nodes[pair[0]], nodes[pair[1]], weight='travel_time'
                )

        # now compute with a progress bar
        from tqdm import tqdm
        print(f"  • Computing {mode} times for {len(pairs)} pairs using {max_workers} workers…")
        mat = np.zeros((n, n), dtype=float)
        with mp.Pool(max_workers) as pool:
            for (i, j), travel_time in tqdm(
                zip(pairs, pool.imap(sp, pairs)),
                total=len(pairs),
                desc=f"{mode.capitalize()} routing",
                leave=False
            ):
                mat[i, j] = travel_time
                mat[j, i] = travel_time

        # save and report
        np.save(npy_path, mat)
        print(f"  ✔ Saved {mode} matrix to {npy_path}\n")

    # run both modes
    # build_and_compute("walk",  walk_npy)
    build_and_compute("drive", drive_npy)
