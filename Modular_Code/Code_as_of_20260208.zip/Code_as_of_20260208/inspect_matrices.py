# -*- coding: utf-8 -*-
"""
Created on Tue Dec 30 15:40:32 2025

@author: bigfo
"""

#!/usr/bin/env python3
"""
# =============================================================================
# OPTIONAL HELPER: Quick inspection of saved .npy matrices (d / dtilde / walk / drive)
# -----------------------------------------------------------------------------
# Why this exists:
#   - When debugging unit conversions, symmetry, missing values, and output naming,
#     it's very helpful to quickly print summary stats for the matrices produced
#     by Steps 3/4 (walk/drive raw times; d and dtilde derived matrices).
#
# How to use (Spyder-friendly):
#   1) Leave RUN_MATRIX_INSPECTOR = False for normal pipeline runs.
#   2) Set RUN_MATRIX_INSPECTOR = True when you want a quick sanity-check printout.
#   3) Point MATRIX_FOLDER at wherever your .npy matrices are saved.
#   4) Optionally adjust the glob patterns (PATTERNS) to match your filenames.
#
# Outputs:
#   - Console printout with:
#       * shape / dtype
#       * NaN/Inf counts (float matrices)
#       * diagonal min/median/max (if square)
#       * symmetry check max|A-A.T| (if square)
#       * percentiles + mean/std (finite values only)
#   - Optional histogram PNG saved next to each matrix (SAVE_HISTS=True).
# =============================================================================
"""

import argparse
import os
import glob
import numpy as np

def _infer_units_heuristic(arr):
    """
    Very rough heuristic for travel-time units.
    Returns a string:
      - 'likely seconds' if typical values look large (hundreds/thousands)
      - 'likely minutes' if typical values look smaller (single/double digits)
      - 'unknown' if no finite values
    NOTE: This is only a hint; your pipeline is the source of truth for units.
    """
    import numpy as np
    finite = arr[np.isfinite(arr)]
    if finite.size == 0:
        return "unknown"
    med = float(np.median(finite))
    # Heuristic thresholds; tweak if your values differ
    if med > 600:   # >10 minutes *in seconds*
        return "likely seconds"
    if med > 200:
        return "seconds/minutes ambiguous"
    return "likely minutes"

def summarize_matrix_npy(npy_path, snippet_n=0, save_hist=False, hist_bins=60):
    """
    Load a .npy matrix and print summary information to the console.

    Parameters
    ----------
    npy_path : str
        Full path to the .npy file on disk.

    snippet_n : int, default 0
        If >0, prints the top-left snippet_n x snippet_n block of the matrix.
        Useful for quick “does this look sane?” checks.

    save_hist : bool, default False
        If True, saves a histogram PNG (finite values only) next to the .npy file.

    hist_bins : int, default 60
        Number of bins for the histogram (only used if save_hist=True).

    Notes
    -----
    This function is designed for quick diagnostics:
      - Detect missing values (NaN/Inf)
      - Check diagonal values (travel matrices should usually have diag ~ 0)
      - Check symmetry (d/dtilde often expected to be symmetric; raw walk/drive may not be)
      - Get distribution summary (percentiles / mean / std)
    """
    import os
    import numpy as np

    print("=" * 90)
    print("Matrix file:", os.path.basename(npy_path))
    print("Path      :", npy_path)

    try:
        A = np.load(npy_path, allow_pickle=False)
    except Exception as e:
        print("FAILED to load .npy:", e)
        return

    print("Shape/dtype:", A.shape, "|", A.dtype)

    # NaN / Inf counts (only meaningful for float matrices)
    if np.issubdtype(A.dtype, np.floating):
        n_nan = int(np.isnan(A).sum())
        n_inf = int(np.isinf(A).sum())
        print(f"NaN/Inf   : NaN={n_nan:,} | Inf={n_inf:,}")
    else:
        print("NaN/Inf   : (non-float dtype; skipping NaN/Inf counts)")

    # Finite distribution summary (ignore NaN/Inf)
    finite = A[np.isfinite(A)] if np.issubdtype(A.dtype, np.floating) else A
    if finite.size > 0 and np.issubdtype(A.dtype, np.number):
        q = np.percentile(finite, [0, 1, 5, 25, 50, 75, 95, 99, 100])
        print("Percentiles (finite): min p01 p05 p25 p50 p75 p95 p99 max")
        print("  " + "  ".join(f"{float(v):8.3f}" for v in q))
        print(f"Mean/Std (finite): mean={float(np.mean(finite)):.3f} | std={float(np.std(finite)):.3f}")
        print("Units (heuristic):", _infer_units_heuristic(A))
    else:
        print("No finite numeric values to summarize.")

    # Diagonal stats + symmetry check (only for square 2D matrices)
    if A.ndim == 2 and A.shape[0] == A.shape[1] and np.issubdtype(A.dtype, np.number):
        diag = np.diag(A)
        diag_f = diag[np.isfinite(diag)] if np.issubdtype(A.dtype, np.floating) else diag
        if diag_f.size:
            print(f"Diagonal (finite): min={float(np.min(diag_f)):.3f} "
                  f"median={float(np.median(diag_f)):.3f} "
                  f"max={float(np.max(diag_f)):.3f}")

        # Symmetry check on finite paired entries
        if np.issubdtype(A.dtype, np.floating):
            mask = np.isfinite(A) & np.isfinite(A.T)
            if mask.any():
                diff = np.abs(A - A.T)
                print(f"Symmetry (finite pairs): max|A-A.T|={float(np.max(diff[mask])):.6f} "
                      f"| mean|A-A.T|={float(np.mean(diff[mask])):.6f}")
        else:
            diff = np.abs(A - A.T)
            print(f"Symmetry: max|A-A.T|={int(np.max(diff))} | mean|A-A.T|={float(np.mean(diff)):.6f}")
    else:
        print("Diagonal/Symmetry: skipped (matrix not square 2D or non-numeric)")

    # Optional snippet
    if snippet_n and A.ndim == 2:
        n = min(snippet_n, A.shape[0], A.shape[1])
        print(f"Top-left {n}x{n} snippet:")
        with np.printoptions(precision=3, suppress=True):
            print(A[:n, :n])

    # Optional histogram
    if save_hist and np.issubdtype(A.dtype, np.number):
        finite = A[np.isfinite(A)] if np.issubdtype(A.dtype, np.floating) else A
        if finite.size == 0:
            print("Histogram: skipped (no finite values).")
        else:
            try:
                import matplotlib.pyplot as plt
                plt.figure()
                plt.hist(finite.flatten(), bins=hist_bins)
                out_png = os.path.splitext(npy_path)[0] + "_hist.png"
                plt.title(os.path.basename(npy_path))
                plt.xlabel("value")
                plt.ylabel("count")
                plt.tight_layout()
                plt.savefig(out_png, dpi=160)
                plt.close()
                print("Histogram saved:", out_png)
            except Exception as e:
                print("Histogram: skipped (matplotlib issue):", e)

def inspect_matrix_folder(matrix_folder,
                          patterns=None,
                          snippet_n=0,
                          save_hists=False,
                          hist_bins=60):
    """
    Scan a folder for .npy matrices and summarize each one.

    Parameters
    ----------
    matrix_folder : str
        Directory containing .npy matrix files.

    patterns : list[str] or None
        Filename patterns (glob) used to select files.
        If None, defaults to the common patterns produced by this pipeline:
          - "*_d_*.npy"      (population-weighted distance)
          - "*_dtilde_*.npy" (mode-adjusted distance)
          - "*_walk_*.npy"   (raw walk travel-time matrix)
          - "*_drive_*.npy"  (raw drive travel-time matrix)

    snippet_n : int
        Passed through to summarize_matrix_npy().

    save_hists : bool
        Passed through to summarize_matrix_npy().

    hist_bins : int
        Passed through to summarize_matrix_npy().
    """
    import os
    import glob

    if patterns is None:
        patterns = ["*_d_*.npy", "*_dtilde_*.npy", "*_walk_*.npy", "*_drive_*.npy"]

    if not matrix_folder or not os.path.isdir(matrix_folder):
        print("Matrix inspector: matrix_folder is not a directory:", matrix_folder)
        return

    all_files = []
    for pat in patterns:
        all_files.extend(glob.glob(os.path.join(matrix_folder, pat)))

    all_files = sorted(set(all_files))
    print(f"\nMatrix inspector: found {len(all_files)} file(s) in {matrix_folder}\n")

    for f in all_files:
        summarize_matrix_npy(f, snippet_n=snippet_n, save_hist=save_hists, hist_bins=hist_bins)


